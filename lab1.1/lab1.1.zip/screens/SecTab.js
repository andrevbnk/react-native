import React from "react";
import { View, Text } from 'react-native'

const SecTab = () => {
    return (
        <View style={{
            flex: 1,
            justifyContent: 'center',
            flexDirection:'column',
            alignItems:'center',
        }}>
            <Text style={{fontSize: 20}}>ME</Text>
        </View>
    )
}

export default SecTab
